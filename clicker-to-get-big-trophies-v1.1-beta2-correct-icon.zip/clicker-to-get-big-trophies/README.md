# 🏆 Clicker to Get Big Trophies

GitHub Pages-färdig projektversion för **Version 1.1 Beta 2**.

## Ladda upp på GitHub

1. Packa upp ZIP-filen.
2. Öppna mappen `clicker-to-get-big-trophies`.
3. Ladda upp **allt innehåll i mappen** till rotmappen i ditt GitHub-repository.
4. Ersätt de gamla filerna när GitHub frågar.
5. Kontrollera att `index.html`, `manifest.json` och `sw.js` ligger direkt i repositoryts rot.
6. Behåll mapparna `css`, `js`, `audio`, `images`, `icons` och `docs` med samma namn.

## Viktigt

- Ändra inte mappnamnen utan att samtidigt ändra sökvägarna i koden.
- Ljudfilerna för Oskar och Maritta ligger nu separat i `audio/`.
- Spelets CSS ligger i `css/style.css`.
- Spelets JavaScript ligger i `js/game.js`.
- Inga befintliga trophies, trophy-beskrivningar eller citat har ändrats vid omstruktureringen.

## Lokal testning

Öppna `index.html` i Chrome. De flesta funktioner fungerar direkt. Service worker och fullständig PWA-installation kräver att spelet körs via GitHub Pages eller en lokal webbserver.
